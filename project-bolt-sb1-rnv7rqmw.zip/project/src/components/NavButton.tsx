import React from 'react';
import { motion } from 'framer-motion';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface NavButtonProps {
  Icon: LucideIcon;
  text: string;
  link: string;
  delay: number;
}

const NavButton: React.FC<NavButtonProps> = ({ Icon, text, link, delay }) => {
  return (
    <motion.a
      href={link}
      initial={{ scale: 0.5, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="relative block p-6 bg-gray-800/50 backdrop-blur-sm rounded-xl transition-all duration-300 border border-red-500/20 hover:border-red-500 group overflow-hidden"
    >
      {/* Neon glow effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-red-500/0 via-red-500/10 to-red-500/0 group-hover:via-red-500/20 transition-all duration-500"></div>
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 to-transparent blur-xl"></div>
        <div className="absolute -inset-1 bg-gradient-to-r from-red-500/20 via-transparent to-red-500/20 animate-pulse-slow"></div>
      </div>
      
      {/* Content */}
      <div className="relative flex flex-col items-center space-y-4">
        <div className="relative">
          <Icon className="w-12 h-12 text-red-500 group-hover:text-red-400 transition-colors duration-300 drop-shadow-[0_0_10px_rgba(239,68,68,0.5)]" />
          <div className="absolute inset-0 bg-red-500/30 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        </div>
        <span className="text-lg font-medium text-center text-white group-hover:text-red-200 transition-colors duration-300 drop-shadow-[0_0_5px_rgba(239,68,68,0.5)]">{text}</span>
      </div>

      {/* Tech lines */}
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-red-500/50 to-transparent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
      <div className="absolute bottom-0 right-0 w-full h-[1px] bg-gradient-to-r from-transparent via-red-500/50 to-transparent transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
    </motion.a>
  );
};

export default NavButton;