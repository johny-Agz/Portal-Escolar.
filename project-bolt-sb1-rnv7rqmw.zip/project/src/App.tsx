import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Users, GraduationCap, BookOpen, Building2, ScrollText } from 'lucide-react';
import ParticlesBackground from './components/ParticlesBackground';
import NavButton from './components/NavButton';

function App() {
  const sections = [
    { icon: Brain, text: 'Comunicados', link: '#' },
    { icon: Users, text: 'Estudiantes', link: '#' },
    { icon: GraduationCap, text: 'Padres', link: '#' },
    { icon: BookOpen, text: 'Profesores', link: '#' },
    { icon: Building2, text: 'Nuestro Colegio', link: '#' },
    { icon: ScrollText, text: 'Reglamentos', link: '#' },
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white relative overflow-hidden">
      <ParticlesBackground />
      
      {/* Tech background elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(239,68,68,0.1)_0%,transparent_70%)]"></div>
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(0,0,0,0.8)_0%,transparent_100%)]"></div>
      
      <div className="relative z-10">
        <header className="py-8 px-4">
          <motion.h1 
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-4xl md:text-6xl font-bold text-center"
          >
            <span className="bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(239,68,68,0.5)]">
              Portal Stark
            </span>
          </motion.h1>
          
          {/* Tech decorative line */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1, delay: 0.8 }}
            className="h-[2px] max-w-[200px] mx-auto mt-4 bg-gradient-to-r from-transparent via-red-500 to-transparent"
          />
        </header>

        <main className="container mx-auto px-4 py-8">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {sections.map((section, index) => (
              <NavButton
                key={index}
                Icon={section.icon}
                text={section.text}
                link={section.link}
                delay={index * 0.1}
              />
            ))}
          </motion.div>
        </main>
      </div>
    </div>
  );
}

export default App;