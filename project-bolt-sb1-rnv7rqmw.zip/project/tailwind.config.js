/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      dropShadow: {
        'neon': '0 0 10px rgba(239, 68, 68, 0.5)',
      },
    },
  },
  plugins: [],
};